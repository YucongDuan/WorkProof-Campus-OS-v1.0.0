# DIKWP WorkProof Campus OS v1.0.0 - START HERE

## 定位

面向职业教育与应用型高校的开源责任内核：AI 真实性任务评价、受保护企业微学徒制、学生价值承诺、具名人工复核、变化情境迁移答辩、可携带能力证据、隐私聚合、申诉与五收据纠错。

本版本为 **研究型商业 Alpha / pre-revenue**。没有真实客户、真实收入、真实就业效果或第三方认证证据。

## 最快运行

```bash
python DIKWP_WORKPROOF_CAMPUS_OS_v1.0.0.pyz demo --workspace .workproof-demo --reset
python DIKWP_WORKPROOF_CAMPUS_OS_v1.0.0.pyz verify-ledger --workspace .workproof-demo
python DIKWP_WORKPROOF_CAMPUS_OS_v1.0.0.pyz conformance
```

## 核心硬边界

- 生产贡献任务必须在分配前存在正向价值承诺以及付款、知识产权、作品集、数据使用和退出条款。
- 可携带能力收据必须具有具名人工复核和变化情境迁移答辩证据链。
- 自动评分、自动招聘、自动付款、官方学徒注册和自动外部行动权限均为 0。
- 不生成一般智力、人类价值或通用就业力排名。
- 学生报酬与平台服务费分离。

## 目录

- `01_OPEN_SOURCE_SYSTEM`：源码、Wheel、PYZ、Git Bundle。
- `02_COMMERCIAL_REPORT`：PDF、DOCX、公式驱动财务模型和分析图。
- `03_PILOT_AND_OPERATIONS`：八周付费试点 SOW、运营手册和指标表。
- `04_WAPE_STANDARDIZATION`：WAPE-1000 规范与标准化专包。
- `05_VALIDATION_AND_SUPPLY_CHAIN`：验证收据、SBOM、发布清单和 SHA-256。

## 恢复完整 Git 历史

```bash
git clone DIKWP_WORKPROOF_CAMPUS_OS_v1.0.0.bundle workproof-campus
cd workproof-campus
PYTHONPATH=src python -m pytest -q
PYTHONPATH=src python -m dikwp_workproof demo --workspace .demo --reset
```

## 许可证

Apache-2.0。请同时阅读源码包中的 `NOTICE`、`SECURITY.md` 与现实边界说明。
