# WAPE-1000:2026-DRAFT

## Work-integrated Apprenticeship and Portable Evidence Protocol
## 产教微学徒与可携带证据协议

**Status:** author-side committee draft / 作者侧委员会草案  
**Implementation:** DIKWP WorkProof Campus OS v1.0.0  
**Normative words:** MUST, MUST NOT, SHOULD, MAY are interpreted as requirement levels.  
**Certification boundary:** no standards-body approval or third-party certification is claimed.

## 1. Scope / 范围

WAPE-1000 specifies records and control obligations for educational programmes that use employer-originated tasks, AI-assisted work, human assessment, portable evidence and employment-adjacent outcomes. It does not define academic credit, labour status, professional licensure, registered apprenticeship approval or automated employment decisions.

## 2. Conformance levels / 符合等级

| Level | Name | Core obligation |
|---|---|---|
| L0 | Agency and scope | purpose, actors, consent, withdrawal and declared authority |
| L1 | Task and value boundary | simulation/learning/production classification and value terms |
| L2 | Authentic evidence | AI-use declaration, named human review and transfer defense |
| L3 | Rights and outcomes | compensation receipts, privacy aggregates, support and appeal |
| L4 | Portability | machine-readable exports and downstream correction propagation |
| L5 | Reproducible responsibility | audit replay, conformance tests and public calibration evidence |

A claim of level `Ln` MUST satisfy all lower levels.

## 3. L0 - agency, purpose and authority

1. The implementation MUST identify the programme, institution and accountable human owner.
2. The implementation MUST state the educational purpose and any employment-adjacent purpose separately.
3. Participation MUST be based on an explicit consent state.
4. Consent MUST NOT be inferred from silence, enrolment dependency or platform use alone.
5. The learner MUST have a documented withdrawal route.
6. Withdrawal or appeal MUST NOT generate a retaliation score.
7. The implementation MUST declare whether it has grading, hiring, payment, disciplinary or apprenticeship-registration authority.
8. A reference evidence platform MUST set undelegated consequential authorities to zero.
9. Role permissions MUST be explicit and tenant-bounded.
10. A learner MUST be able to request reasonable support without public disclosure of the support profile.

## 4. L1 - task and value boundary

11. Every employer-originated task MUST be classified as `SIMULATION`, `LEARNING_ONLY` or `PRODUCTION_CONTRIBUTION`.
12. The classification MUST be visible before learner assignment.
13. A task that may create usable employer value SHOULD be classified as `PRODUCTION_CONTRIBUTION` when uncertainty remains.
14. A production-contribution task MUST have positive compensation or another positive value transfer accepted under applicable rules.
15. Compensation MUST be recorded separately from platform service fees.
16. Payment timing MUST be written before assignment.
17. Authorship and IP terms MUST be written before assignment.
18. Portfolio-use terms MUST be written before assignment.
19. Data-use and retention terms MUST be written before assignment.
20. The institution MUST approve the task-value classification before activation.
21. An employer MUST NOT unilaterally convert learning-only output into production use without a new value agreement.
22. A value commitment MUST identify the learner, assignment, employer, amount/type, currency and due condition.
23. The implementation MUST distinguish a commitment from a confirmed transfer.
24. A confirmed transfer MUST reference an external or human-verifiable receipt.
25. The implementation MUST expose uncompensated production assignments as a violation, not as a successful placement metric.

## 5. L2 - AI-use and authentic evidence

26. Every brief MUST declare an AI-use policy: `PROHIBITED`, `DISCLOSED` or `REQUIRED`.
27. A submission MUST declare whether AI was used.
28. When AI was used, the tool, purpose and human-verification method MUST be declared.
29. Restricted data MUST NOT be sent to an AI tool without an independently authorized control profile.
30. The reference core MUST reject restricted-data AI use.
31. A consequential assessment MUST identify a named human reviewer.
32. Automated suggestions MUST NOT be represented as the final human judgement.
33. The rubric and criterion evidence MUST be versionable and recoverable.
34. A polished final artifact alone MUST NOT be sufficient for a portable capability claim.
35. The learner MUST respond to a materially changed prompt, condition, audience, source or constraint.
36. A transfer defense MUST identify the changed context and the human reviewer.
37. A portable receipt MUST have a passing human review and a passing transfer defense.
38. The receipt MUST identify the source submission, competency, stage, issuer and issuance time.
39. Receipt revocation and correction status MUST be representable.
40. The implementation MUST NOT derive a general intelligence or human-worth score from task receipts.

## 6. L3 - support, privacy, outcomes and correction

41. Support requests MUST be access-controlled and excluded from public passports by default.
42. Programme aggregates MUST declare a minimum privacy threshold.
43. Counts below the threshold MUST be suppressed rather than reported as zero.
44. The system MUST NOT publish an individual leaderboard as an aggregate outcome.
45. Employer acknowledgements MUST be separated from hiring decisions.
46. Outcome receipts MUST identify type, evidence source, verifier and date.
47. Observational outcomes MUST NOT be labelled causal impact.
48. Employment and earnings claims SHOULD use an independent evaluation design when used for high-stakes funding or policy.
49. Learners MUST be able to appeal a receipt or consequential record.
50. An upheld appeal MUST restore the relevant opportunity or access.
51. An upheld appeal MUST correct the source record.
52. An upheld appeal MUST notify known downstream recipients.
53. An upheld appeal MUST compensate verified loss or explicitly document why no loss exists.
54. An upheld appeal MUST revise or retire the contradicted model, rubric or template.
55. Correction MUST remain open until all five receipt classes exist.
56. Appeal activity MUST NOT lower service priority or eligibility.
57. The programme report MUST disclose open appeals and correction status.
58. The audit trail MUST preserve the original record and the correction rather than silently overwriting history.

## 7. L4 - portability and interoperability

59. A learner MUST be able to export their active capability receipts.
60. The default passport MUST exclude support profiles, appeal reasons, private notes and general rankings.
61. The export MUST state that it is not autonomous hiring authority.
62. The export MUST state whether it is signed, unsigned or independently verified.
63. Reference mappings MAY use W3C Verifiable Credentials, Open Badges or CLR.
64. A mapping MUST NOT claim certification by an external standards body without evidence.
65. Downstream systems receiving corrected evidence SHOULD support revocation or correction propagation.
66. Data connectors MUST declare purpose, destination, fields, retention and human authorization.

## 8. L5 - reproducibility, governance and conformance

67. Consequential mutations MUST be represented in an append-only or tamper-evident ledger.
68. Ledger verification MUST detect broken predecessor links and changed event bodies.
69. The implementation MUST provide deterministic conformance fixtures for positive and negative cases.
70. Constitutional invariants MUST be machine-testable.
71. The implementation SHOULD publish a bounded model or formal state-machine representation.
72. Finite model-checking results MUST disclose their state-space boundary and MUST NOT be presented as universal proof.
73. A conformance claim MUST identify the implementation version, test version, self/third-party status, unmet requirements and legal boundary.

## Annex A - Minimum production brief

```json
{
  "task_mode": "PRODUCTION_CONTRIBUTION",
  "ai_policy": "DISCLOSED",
  "minimum_compensation": 800,
  "currency": "CNY",
  "payment_terms": "within 15 days of accepted work",
  "ip_terms": "learner authorship retained; declared licence only",
  "portfolio_terms": "redacted portfolio use allowed",
  "data_use_terms": "no undeclared reuse"
}
```

## Annex B - Five-receipt correction closure

```text
RESTORE_OPPORTUNITY
+ CORRECT_RECORD
+ NOTIFY_DOWNSTREAM
+ COMPENSATE_VERIFIED_LOSS
+ REVISE_OR_RETIRE_MODEL
= CORRECTION_CLOSED
```

## Annex C - Non-equivalence rules

```text
artifact polish != transferable capability
employer usefulness != hiring eligibility
course enrolment != informed consent
value commitment != value transfer
badge export != standards certification
micro-apprenticeship != registered apprenticeship
observed outcome != causal impact
```
