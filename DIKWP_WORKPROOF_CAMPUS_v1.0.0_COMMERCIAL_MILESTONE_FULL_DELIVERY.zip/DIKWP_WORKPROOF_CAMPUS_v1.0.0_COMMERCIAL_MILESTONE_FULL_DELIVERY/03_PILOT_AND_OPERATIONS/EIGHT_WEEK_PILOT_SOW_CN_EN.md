# DIKWP WorkProof Campus - 八周付费试点工作说明书 / Eight-Week Paid Pilot SOW

## 1. 目标 / Objective

在一个具名院校专业群中，以不超过 50 名自愿参加者、3 家企业和 4 个任务，验证以下能力：

- 区分模拟、学习型和生产贡献型任务；
- 对生产贡献形成正向报酬、知识产权、作品集和数据使用承诺；
- 记录 AI 使用、人工复核和变化情境迁移答辩；
- 输出隐私保护的项目级证效档案和学习者可携带证据；
- 建立申诉和五收据纠错闭环。

The pilot validates task-value classification, learner rights, AI-use disclosure, named human assessment, changed-context transfer, portable evidence, privacy-protected programme reporting and correction closure.

## 2. 范围 / Scope

- 1 institution and 1 programme cluster;
- up to 50 learners;
- 3 employer partners;
- 4 governed briefs, including at least one compensated production-contribution brief;
- 2-6 named institutional reviewers;
- one configured self-hosted or managed instance;
- one final assurance dossier and scale recommendation.

## 3. 周次 / Workplan

| 周 | 工作 | 书面交付 |
|---|---|---|
| 1 | 目的、买方、角色、法律和数据边界 | 范围表、责任矩阵、退出机制 |
| 2 | 能力模型和企业任务价值分类 | 任务卡、量规、报酬/IP/作品集条款 |
| 3 | 系统配置、评审校准、学习者同意 | 配置清单、评审手册、同意记录 |
| 4-5 | 任务执行、AI 使用声明、支持 | 提交物、支持票据、过程记录 |
| 6 | 具名人工复核和迁移答辩 | 评审与答辩收据 |
| 7 | 企业确认、价值转移、结果记录 | 企业确认及付款收据 |
| 8 | 聚合报告、申诉窗口、扩展决策 | 证效档案、风险清单、下一阶段方案 |

## 4. 费用 / Fees

Indicative service fee: **CNY 198,000-398,000**, depending on deployment, task design, review operations and integration. Learner compensation, employer sponsorship, travel and third-party evaluation are separately budgeted.

定制工作必须在书面范围、首付款和数据责任确认后开始。不得把免费原型、免费企业招募或无限次评审视为售前义务。

## 5. 验收 / Acceptance

- system runs in the agreed environment;
- all production briefs have positive value commitments before assignment;
- all portable receipts have named human review and transfer-defense evidence;
- privacy threshold is enforced;
- audit chain verifies;
- appeals can complete the five-receipt correction workflow;
- final dossier states limitations and does not claim causal employment impact without a separate design.

## 6. 排除 / Exclusions

No automatic grading, admissions, hiring, compensation, disciplinary action, official apprenticeship registration, legal opinion, guaranteed placement or guaranteed ROI is included.
