# Pilot Operating Playbook

## Before contracting

1. Confirm a named institutional budget owner.
2. Select one programme and one measurable bottleneck.
3. Require three employer contacts willing to sign task-value and data terms.
4. Refuse any scope whose business case depends on secret learner ranking or free production work.
5. Put all custom work, reviewer capacity, employer recruitment and integrations into the paid statement of work.

## Brief triage

- If no external use is intended: `SIMULATION` or `LEARNING_ONLY`.
- If the employer may use the output, avoid a cost, improve a process or create an asset: `PRODUCTION_CONTRIBUTION`.
- When uncertain, classify upward and require the stronger learner protections.

## Reviewer calibration

Reviewers independently score two anchor artifacts, compare reasoning, document disagreements and revise the rubric. Automated suggestions may organize evidence but may not issue the consequential decision.

## Red flags

- the employer refuses written IP or data-use terms;
- compensation is conditional on an opaque satisfaction standard;
- a learner cannot withdraw without academic retaliation;
- the task uses restricted data with consumer AI tools;
- the institution asks for a single employability score;
- a small cohort is published despite re-identification risk;
- the buyer asks to suppress appeals or negative learner feedback.

## Scale decision

Scale only when evidence shows operational usefulness to the institution, learner rights compliance, repeat employer participation, a viable delivery margin and at least one real decision changed by the dossier.
